var f=require("fs");
f.readFile("text1.html",function(e,dat){
    if(e){
        console.log(e)
    }
    setTimeout(()=>{
        console.log("display after 5 seconds")
    },5000)
})
console.log("start")