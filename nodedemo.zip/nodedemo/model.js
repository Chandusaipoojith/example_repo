var mongoose=require('mongoose')
var Schema=mongoose.Schema
var userSchema=new Schema({
    Data:{
        StudentName:{
            type:String,
            required:true
        },
        Id:{
            type:String,
            required: true
        },
        Branch:{
            type:String,
            required:true
        }
    }
   
});
var User=mongoose.model('User',userSchema)
module.exports=User