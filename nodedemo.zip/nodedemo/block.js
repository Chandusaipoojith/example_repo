
var f= require("fs");
var da=f.readFileSync("text1.html");
console.log(da.toLocaleString())
console.log("end")