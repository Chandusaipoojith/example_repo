var mongoose=require('mongoose')
var User=require('./model.js')
var http=require("http")
http.createServer((req,res)=>{
    mongoose.connect('mongodb://localhost:27017/KLWE',
    function(err){
        if(err) throw error.writeHead(200,
            {'Content-Type':'text/html'})
            res.write('Successfully completed </br>')
            var UserObject=new User({
                Data:{
                    StudentName:'Lohith Maturi',
                    Id         :  "2100032244",
                    Branch     :  "CSE"
                }
            });
            UserObject.save(function(err){
                if(err)throw err
            })
            User.find({},function(err,dbStudent){
                if(err) throw err;
                res.write(JSON.stringify(dbStudent));
                res.end();
            });

    }
    );
}
).listen(8002,
    ()=>console.log("http server is running"));