var http=require("http");
http.createServer((req,res)=>{
    res.write("<h1> Welcome to pokemon battle");
    res.end();

}).listen(7008,
    ()=>console.log("http server is running"));