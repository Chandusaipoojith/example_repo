const express=require("express")
const app=express()
app.get('/',(req,res)=>res.send("<h1><marquee>Hello World"))
app.listen("7999",()=>console.log("http server is running"))